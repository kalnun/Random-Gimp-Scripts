Installation and usage instructions for the animated kaleidoscope script/plugin combo.




Place the kaleidoscope.exe file in your GIMP plugins folder (like so): C:\Program Files\GIMP-2.0\lib\gimp\2.0\plug-ins 

(Please note: the plugin was not developed nor maintained by me.  It used to be part of the GIMP program, but has not been incorporated in the last few releases.)

Place the fp-kaleidoscope-anim.scm file in your GIMP scripts folder (like so): C:\Program Files\GIMP-2.0\share\gimp\2.0\scripts

Restart GIMP so that the plugin is recognized by GIMP.

Works on RGB, and grayscale images.  If you're animation or single image is a gif or an indexed image, you must convert it to RGB or grayscale first.  To do that, go to Image > Mode and choose the desired format.

Go to Filters > Animation > Kaleidoscope Animation...

When the script dialog opens, choose the desired parameters and hit OK to run.  When the Kaleidoscope filter opens, set the desired parameters, click the OK button and your animated kaleidoscope will be created.


I've tried to make the script options as self-explanatory as possible, but here are some details:

"Create Kaleidoscope On" - You have two options: an existing animation or a single image.  If you select "existing animation" and your image only has 1 layer in it, GIMP will give you an error and you'll have to select the "on a single image" option.  Likewise, if you choose "on a single image" and your image is multi-layer, you'll get an error.

"Number of frames" - This only works on the "single image" option.  You tell GIMP how many layers it should create"  GIMP will automatically move your image the necessary direction and spacing.  One thing to note: if the spacing needed to move is less than 1 pixel each time, GIMP will give you an error telling you that you have too many frames.  For example:  if your image is 150 X 75 pixels and you want the resulting animation to be 100 frames, it will give you an error.  GIMP calculates the spacing each frame needs to be moved by dividing the number of frames into the image width and height.  Using my example image of 150 X 75, 75 divided by 100 is less than 1, so you'll get an error.

"Direction to move layer" - This only works on the "single image" option.  GIMP will move each layer to correct spacing in the chosen direction.  

"Animation speed" - Should be self-explanatory.  The lower the number, the faster the animation.

"Use existing selection" - Only works when applying the kaleidoscope plugin to an existing animation.  This limits the effect to the selection area.  By making a selection, running the script and re-doing it again and again, you can come up with some pretty neat effects (or really ugly depending on how things go!)  

"Delete area outside of selection" - Again only works on an existing animation.  Applies the kaleidoscope to the selected area and deletes everything outside of it.

"Semi-flatten" - Only works on an existing animation and only if the delete option is used.  The purpose of this is that animated gifs often leave shart edges that don't blend well with backgrounds.  By using this option in conjunction with the "background color" option, you can choose a color similar to that of your webpage and it will help with the blending.  Does not always work with multi-colored backgrounds or in every situation.

"background color" - See semi-flatten description.

If you have any questions or comments, feel free to contact me at: fence-post.deviantart.com

Enjoy and Cheers!

Art



